# ArbitrageX — Deployment Guide

## Table of Contents
1. [What You Need Before Deploying](#1-what-you-need-before-deploying)
2. [Build the Project Locally](#2-build-the-project-locally)
3. [Deployment Options](#3-deployment-options)
   - [Option A: Vercel (Recommended — Free)](#option-a-vercel-recommended--free)
   - [Option B: Netlify (Free)](#option-b-netlify-free)
   - [Option C: GitHub Pages (Free)](#option-c-github-pages-free)
   - [Option D: VPS / Dedicated Server (Advanced)](#option-d-vps--dedicated-server-advanced)
   - [Option E: Cloudflare Pages (Free)](#option-e-cloudflare-pages-free)
4. [Environment Variables & API Keys](#4-environment-variables--api-keys)
5. [Custom Domain Setup](#5-custom-domain-setup)
6. [Security Checklist](#6-security-checklist)
7. [Troubleshooting](#7-troubleshooting)

---

## 1. What You Need Before Deploying

- **Node.js** v18 or higher → https://nodejs.org
- **npm** v9 or higher (comes with Node.js)
- **Git** → https://git-scm.com
- A **GitHub / GitLab / Bitbucket** account (for CI/CD deployments)
- API keys from exchanges you want to connect (Binance, Bybit, MEXC, HTX, KuCoin, BitMart, Bitget, Gate.io)

---

## 2. Build the Project Locally

```bash
# 1. Clone or download the project
git clone https://github.com/YOUR_USERNAME/arbitragex.git
cd arbitragex

# 2. Install dependencies
npm install

# 3. Build for production
npm run build

# 4. Preview the build locally (optional)
npm run preview
```

After `npm run build`, a `dist/` folder is created. The `dist/index.html` file is a **single self-contained HTML file** (all JS/CSS is inlined) thanks to `vite-plugin-singlefile`. You can open it directly in a browser or serve it via any web server.

---

## 3. Deployment Options

---

### Option A: Vercel (Recommended — Free)

Vercel is the fastest way to deploy. It auto-builds on every Git push.

#### Steps:

**Method 1 — Vercel Dashboard (No CLI needed)**

1. Push your project to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/arbitragex.git
   git push -u origin main
   ```

2. Go to → https://vercel.com and sign in with GitHub.

3. Click **"Add New Project"** → Import your `arbitragex` repository.

4. Vercel auto-detects Vite. Confirm these settings:
   - **Framework Preset:** Vite
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`

5. Click **Deploy**. Your site will be live at:
   `https://arbitragex.vercel.app` (or your chosen project name)

**Method 2 — Vercel CLI**

```bash
# Install Vercel CLI globally
npm install -g vercel

# Deploy from project root
vercel

# Follow the prompts:
# ? Set up and deploy? Yes
# ? Which scope? (your account)
# ? Link to existing project? No
# ? What's your project name? arbitragex
# ? In which directory is your code located? ./
# Auto-detected Vite → confirm settings

# To deploy to production:
vercel --prod
```

---

### Option B: Netlify (Free)

#### Method 1 — Drag & Drop (Fastest)

1. Run `npm run build` locally
2. Go to → https://app.netlify.com/drop
3. Drag and drop your entire `dist/` folder onto the page
4. Your site is live instantly at a `*.netlify.app` URL

#### Method 2 — Git Integration (Auto-deploy on push)

1. Push project to GitHub (same steps as Vercel above)
2. Go to → https://app.netlify.com → **"Add new site"** → **"Import an existing project"**
3. Connect GitHub → Select your repo
4. Configure:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Click **Deploy site**

#### Method 3 — Netlify CLI

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build first
npm run build

# Deploy (draft preview)
netlify deploy --dir=dist

# Deploy to production
netlify deploy --dir=dist --prod
```

---

### Option C: GitHub Pages (Free)

GitHub Pages serves static files directly from your repository.

1. Install the `gh-pages` package:
   ```bash
   npm install -D gh-pages
   ```

2. Add to your `package.json` scripts:
   ```json
   "scripts": {
     "deploy": "npm run build && gh-pages -d dist"
   }
   ```

3. If your repo is NOT at the root domain, add `base` to `vite.config.ts`:
   ```ts
   export default defineConfig({
     base: '/arbitragex/',   // <-- your repo name
     plugins: [...]
   })
   ```

4. Deploy:
   ```bash
   npm run deploy
   ```

5. In your GitHub repo → **Settings** → **Pages** → Source: `gh-pages` branch

6. Live at: `https://YOUR_USERNAME.github.io/arbitragex/`

---

### Option D: VPS / Dedicated Server (Advanced)

Use this if you need full server control (e.g., for a real backend/API later).

**Recommended providers:**
- DigitalOcean Droplet → https://digitalocean.com ($6/mo)
- Linode/Akamai → https://linode.com ($5/mo)
- Vultr → https://vultr.com ($6/mo)
- Hetzner (cheapest) → https://hetzner.com (~€4/mo)

#### Steps (Ubuntu 22.04):

```bash
# 1. SSH into your VPS
ssh root@YOUR_SERVER_IP

# 2. Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 3. Install Nginx
sudo apt install -y nginx

# 4. Install Git
sudo apt install -y git

# 5. Clone your project
cd /var/www
git clone https://github.com/YOUR_USERNAME/arbitragex.git
cd arbitragex

# 6. Install & Build
npm install
npm run build

# 7. Configure Nginx
sudo nano /etc/nginx/sites-available/arbitragex
```

Paste this Nginx config:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    root /var/www/arbitragex/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";
}
```

```bash
# 8. Enable the site
sudo ln -s /etc/nginx/sites-available/arbitragex /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# 9. Set up SSL with Let's Encrypt (free HTTPS)
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# 10. Auto-renew SSL
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

#### Auto-deploy on Git push (optional):

```bash
# On your VPS, create a deploy script
nano /var/www/arbitragex/deploy.sh
```

```bash
#!/bin/bash
cd /var/www/arbitragex
git pull origin main
npm install
npm run build
echo "Deployed successfully at $(date)"
```

```bash
chmod +x /var/www/arbitragex/deploy.sh
# Run manually: /var/www/arbitragex/deploy.sh
```

---

### Option E: Cloudflare Pages (Free)

Cloudflare Pages offers unlimited bandwidth and global CDN.

1. Push project to GitHub
2. Go to → https://dash.cloudflare.com → **Workers & Pages** → **Create Application** → **Pages** → **Connect to Git**
3. Select your repository
4. Configure:
   - **Framework preset:** Vite
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
5. Click **Save and Deploy**
6. Live at: `https://arbitragex.pages.dev`

---

## 4. Environment Variables & API Keys

**⚠️ NEVER hardcode API keys in your source code.**

When you're ready to connect real exchange APIs:

### For Vercel:
1. Dashboard → Your Project → **Settings** → **Environment Variables**
2. Add variables like:
   ```
   VITE_BINANCE_API_KEY=your_key_here
   VITE_BINANCE_SECRET=your_secret_here
   VITE_BYBIT_API_KEY=your_key_here
   ...
   ```
3. In your code, access via: `import.meta.env.VITE_BINANCE_API_KEY`

### For Netlify:
1. Site Settings → **Environment Variables** → Add variables (same naming as above)

### For VPS:
Create a `.env` file in the project root (never commit this to Git):
```bash
VITE_BINANCE_API_KEY=your_key_here
VITE_BINANCE_SECRET=your_secret_here
```
Add `.env` to your `.gitignore`:
```bash
echo ".env" >> .gitignore
```

### Exchange API Key Permissions Needed:
| Permission | Required For |
|-----------|-------------|
| Read / View | Scanner (price/balance fetching) |
| Trade | Bot execution (buy/sell orders) |
| Withdrawal | Fund transfers between exchanges |
| IP Whitelist | ✅ Strongly recommended — whitelist your server IP |

---

## 5. Custom Domain Setup

### On Vercel:
1. Project → **Settings** → **Domains** → Add your domain
2. Update DNS at your registrar:
   - `A` record → `76.76.21.21`
   - `CNAME` record (www) → `cname.vercel-dns.com`

### On Netlify:
1. Site Settings → **Domain Management** → **Add custom domain**
2. Update DNS:
   - `A` record → `75.2.60.5`
   - `CNAME` (www) → `YOUR_SITE.netlify.app`

### On Cloudflare Pages:
1. Workers & Pages → Your project → **Custom domains** → Add domain
2. If domain is already on Cloudflare, it auto-configures.

### Recommended Domain Registrars:
- Namecheap → https://namecheap.com (~$10/yr)
- Cloudflare Registrar → https://cloudflare.com/products/registrar (at-cost pricing)
- Google Domains (now Squarespace) → https://domains.squarespace.com

---

## 6. Security Checklist

Before going live with real API keys and funds:

- [ ] **Never commit API keys** — Use environment variables only
- [ ] **Enable IP whitelisting** on all exchange API keys (whitelist your server IP)
- [ ] **Use read-only keys** for the scanner, separate keys with trade/withdraw for bot
- [ ] **Enable HTTPS** — All platforms above provide free SSL
- [ ] **Set withdrawal limits** on each exchange API key as a safety cap
- [ ] **Add API key restrictions** — Restrict to specific endpoints where possible
- [ ] **Use a firewall** on VPS — `ufw allow 80,443/tcp && ufw enable`
- [ ] **Restrict CORS** if you add a backend API layer
- [ ] **Monitor logs** — Check Vercel/Netlify function logs or VPS syslog regularly
- [ ] **Test with small amounts** first before running large trades
- [ ] **Enable 2FA** on all exchange accounts and your hosting account

---

## 7. Troubleshooting

### Build fails with TypeScript errors
```bash
npm run build 2>&1 | head -50
# Fix any TS errors, then rebuild
```

### Blank page after deployment
- Check browser console for errors (F12)
- If using GitHub Pages, make sure `base` is set in `vite.config.ts`
- Ensure `dist/` folder is the publish directory (not `dist/src`)

### API keys not working
- Verify the key has the correct permissions on the exchange
- Check that IP whitelisting includes your deployment server IP
- Confirm the key isn't expired or deactivated

### CORS errors when calling exchange APIs
- Exchange APIs generally require a **backend proxy** — direct browser calls are blocked by CORS
- Solution: Add a lightweight backend (Node.js/Express or serverless functions on Vercel/Netlify)
- Example Vercel serverless function at `api/proxy.ts` to forward requests

### Site works locally but not in production
- Make sure all environment variables are set on the hosting platform
- Check that `.env` file is NOT deployed (it should be in `.gitignore`)

---

## Quick Reference — Recommended Path

```
Beginner:     Netlify Drag & Drop  →  netlify.com/drop
Standard:     Vercel Git Deploy    →  vercel.com
Custom/Scale: VPS + Nginx          →  digitalocean.com or hetzner.com
```

---

*ArbitrageX Deployment Guide — Keep your API keys safe and always test with small amounts first.*
