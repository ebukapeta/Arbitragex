import React, { useState } from "react";

type Section = "overview" | "build" | "vercel" | "netlify" | "github" | "vps" | "cloudflare" | "envvars" | "domain" | "security" | "troubleshoot";

const Badge: React.FC<{ color: string; children: React.ReactNode }> = ({ color, children }) => {
  const colors: Record<string, string> = {
    green:  "bg-green-500/20 text-green-400 border border-green-500/30",
    blue:   "bg-blue-500/20 text-blue-400 border border-blue-500/30",
    yellow: "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30",
    red:    "bg-red-500/20 text-red-400 border border-red-500/30",
    purple: "bg-purple-500/20 text-purple-400 border border-purple-500/30",
    cyan:   "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30",
    orange: "bg-orange-500/20 text-orange-400 border border-orange-500/30",
  };
  return <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${colors[color]}`}>{children}</span>;
};

const CodeBlock: React.FC<{ code: string; language?: string }> = ({ code, language = "bash" }) => {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group my-3 rounded-xl overflow-hidden border border-gray-700/60">
      <div className="flex items-center justify-between bg-gray-900/80 px-4 py-2 border-b border-gray-700/40">
        <span className="text-xs text-gray-500 font-mono uppercase tracking-wider">{language}</span>
        <button onClick={handleCopy} className="text-xs text-gray-400 hover:text-cyan-400 transition-colors flex items-center gap-1.5">
          {copied ? <><span className="text-green-400">✓</span><span className="text-green-400">Copied!</span></> : <><span>⎘</span>Copy</>}
        </button>
      </div>
      <pre className="bg-gray-950/70 p-4 overflow-x-auto text-sm text-gray-300 font-mono leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
};

const Step: React.FC<{ num: number; title: string; children?: React.ReactNode }> = ({ num, title, children }) => (
  <div className="flex gap-4 mb-6">
    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-lg">
      {num}
    </div>
    <div className="flex-1">
      <h4 className="text-white font-semibold mb-2">{title}</h4>
      <div className="text-gray-300 text-sm leading-relaxed">{children}</div>
    </div>
  </div>
);

const Alert: React.FC<{ type: "info" | "warning" | "success" | "danger"; children: React.ReactNode }> = ({ type, children }) => {
  const styles = {
    info:    "bg-blue-500/10 border-blue-500/40 text-blue-300",
    warning: "bg-yellow-500/10 border-yellow-500/40 text-yellow-300",
    success: "bg-green-500/10 border-green-500/40 text-green-300",
    danger:  "bg-red-500/10 border-red-500/40 text-red-300",
  };
  const icons = { info: "ℹ️", warning: "⚠️", success: "✅", danger: "🚨" };
  return (
    <div className={`border rounded-xl p-4 mb-4 flex gap-3 text-sm ${styles[type]}`}>
      <span className="text-lg flex-shrink-0">{icons[type]}</span>
      <div>{children}</div>
    </div>
  );
};

const SectionCard: React.FC<{ title: string; icon: string; children: React.ReactNode; accent?: string }> = ({
  title, icon, children, accent = "from-cyan-500/20 to-blue-600/20"
}) => (
  <div className={`rounded-2xl border border-gray-700/50 bg-gradient-to-br ${accent} bg-gray-800/40 p-5 mb-5 backdrop-blur-sm`}>
    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-3">
      <span className="text-2xl">{icon}</span>
      {title}
    </h3>
    {children}
  </div>
);

const navItems: { id: Section; label: string; icon: string }[] = [
  { id: "overview",    label: "Overview",       icon: "🗺️" },
  { id: "build",       label: "Build Locally",  icon: "🔨" },
  { id: "vercel",      label: "Vercel",         icon: "▲"  },
  { id: "netlify",     label: "Netlify",        icon: "🌐" },
  { id: "github",      label: "GitHub Pages",   icon: "🐙" },
  { id: "vps",         label: "VPS Server",     icon: "🖥️" },
  { id: "cloudflare",  label: "Cloudflare",     icon: "☁️" },
  { id: "envvars",     label: "API Keys & Env", icon: "🔑" },
  { id: "domain",      label: "Custom Domain",  icon: "🌍" },
  { id: "security",    label: "Security",       icon: "🔒" },
  { id: "troubleshoot",label: "Troubleshoot",   icon: "🛠️" },
];

const DeploymentGuide: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [activeSection, setActiveSection] = useState<Section>("overview");
  // sidebar collapsed state (mobile default: collapsed; desktop: always shown via CSS)
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSelectSection = (id: Section) => {
    setActiveSection(id);
    setSidebarOpen(false); // collapse sidebar after selection on mobile
  };

  const activeLabel = navItems.find(n => n.id === activeSection);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-gray-950/98 backdrop-blur-sm overflow-hidden">

      {/* ── Top bar (always visible) ─────────────────────── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 bg-gray-900/90 border-b border-gray-700/50">
        <div className="flex items-center gap-3">
          {/* Mobile: hamburger to toggle sidebar */}
          <button
            onClick={() => setSidebarOpen(v => !v)}
            className="sm:hidden p-1.5 rounded-lg bg-gray-800 text-gray-400 hover:text-white transition-colors"
          >
            {sidebarOpen
              ? <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
              : <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
            }
          </button>
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
            <span className="text-white text-xs font-bold">📦</span>
          </div>
          <div>
            <span className="text-white font-bold text-sm">Deploy Guide</span>
            {/* Current section breadcrumb on mobile */}
            {activeLabel && (
              <span className="sm:hidden text-gray-500 text-xs ml-2">
                {activeLabel.icon} {activeLabel.label}
              </span>
            )}
          </div>
        </div>
        <button
          onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded-lg text-xs font-medium transition-colors border border-gray-700"
        >
          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
          </svg>
          Close
        </button>
      </div>

      {/* ── Body: sidebar + content ──────────────────────── */}
      <div className="flex flex-1 overflow-hidden relative">

        {/* Mobile sidebar overlay */}
        {sidebarOpen && (
          <div
            className="sm:hidden fixed inset-0 bg-black/50 z-10"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <div className={`
          fixed sm:relative top-0 left-0 h-full z-20
          w-56 flex-shrink-0 bg-gray-900/95 border-r border-gray-700/50 flex flex-col
          transition-transform duration-200 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          sm:translate-x-0 sm:block
          ${/* on desktop sidebar occupies its own space */''}
        `}
        style={{ top: 0 }}
        >
          {/* Sidebar header spacer on mobile (behind top bar) */}
          <div className="sm:hidden h-14 flex-shrink-0" />

          <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelectSection(item.id)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all flex items-center gap-2.5 ${
                  activeSection === item.id
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold"
                    : "text-gray-400 hover:bg-gray-800 hover:text-gray-200"
                }`}
              >
                <span className="w-5 text-center flex-shrink-0">{item.icon}</span>
                <span className="truncate">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-700/50 flex-shrink-0">
            <div className="bg-gray-800/60 rounded-xl p-3 text-center">
              <p className="text-gray-500 text-xs mb-1.5">Also available as</p>
              <div className="text-cyan-400 text-xs font-mono bg-gray-900/50 rounded-lg px-2 py-1">
                DEPLOYMENT.md
              </div>
              <p className="text-gray-600 text-[10px] mt-1">in project root</p>
            </div>
          </div>
        </div>

        {/* ── Main Content ──────────────────────────────── */}
        <div className="flex-1 overflow-y-auto sm:ml-0">
          <div className="max-w-3xl mx-auto px-4 sm:px-8 py-6 sm:py-8">

            {/* ── OVERVIEW ── */}
            {activeSection === "overview" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Deployment Overview</h2>
                  <p className="text-gray-400">Choose the right hosting option for ArbitrageX</p>
                </div>
                <Alert type="warning">
                  <strong>Important:</strong> This tool currently runs as a frontend-only app with simulated data. To connect real exchange APIs you need a backend server (Node.js/Express or serverless functions) to proxy API calls securely — direct browser-to-exchange API calls are blocked by CORS on most exchanges.
                </Alert>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  {[
                    { id: "vercel",     title: "Vercel",          tag: "Recommended", color: "cyan",   icon: "▲",  desc: "Auto-deploy from GitHub. Free tier. Best DX.", time: "~3 min", cost: "Free" },
                    { id: "netlify",    title: "Netlify",         tag: "Popular",     color: "green",  icon: "🌐", desc: "Drag & drop deploy or Git integration.", time: "~2 min", cost: "Free" },
                    { id: "github",     title: "GitHub Pages",    tag: "Simple",      color: "purple", icon: "🐙", desc: "Free hosting from your GitHub repo.", time: "~5 min", cost: "Free" },
                    { id: "cloudflare", title: "Cloudflare",      tag: "Fast CDN",    color: "orange", icon: "☁️", desc: "Global CDN, unlimited bandwidth.", time: "~5 min", cost: "Free" },
                    { id: "vps",        title: "VPS Server",      tag: "Advanced",    color: "blue",   icon: "🖥️", desc: "Full control — needed for real backend.", time: "~30 min", cost: "$5-10/mo" },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4 hover:border-gray-600/50 transition-colors text-left"
                      onClick={() => handleSelectSection(opt.id as Section)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{opt.icon}</span>
                          <span className="text-white font-bold">{opt.title}</span>
                        </div>
                        <Badge color={opt.color}>{opt.tag}</Badge>
                      </div>
                      <p className="text-gray-400 text-sm mb-3">{opt.desc}</p>
                      <div className="flex gap-3 text-xs">
                        <span className="text-gray-500">⏱ {opt.time}</span>
                        <span className="text-gray-500">💰 {opt.cost}</span>
                      </div>
                    </button>
                  ))}
                </div>
                <SectionCard title="What You Need Before Starting" icon="📋" accent="from-purple-500/10 to-pink-500/10">
                  <div className="space-y-3">
                    {[
                      { tool: "Node.js v18+",       url: "https://nodejs.org",   desc: "JavaScript runtime for building the project" },
                      { tool: "npm v9+",             url: null,                   desc: "Comes bundled with Node.js" },
                      { tool: "Git",                 url: "https://git-scm.com", desc: "Required for cloud platform CI/CD" },
                      { tool: "GitHub Account",      url: "https://github.com",  desc: "Needed for Vercel, Netlify, GitHub Pages, Cloudflare" },
                      { tool: "Exchange API Keys",   url: null,                   desc: "Binance, Bybit, MEXC, HTX, KuCoin, BitMart, Bitget, Gate.io" },
                    ].map((item) => (
                      <div key={item.tool} className="flex items-start gap-3 bg-gray-900/40 rounded-lg p-3">
                        <span className="text-green-400 mt-0.5">✓</span>
                        <div>
                          <span className="text-white font-medium text-sm">{item.tool}</span>
                          {item.url && <span className="text-cyan-400 text-xs ml-2 font-mono">{item.url}</span>}
                          <p className="text-gray-500 text-xs mt-0.5">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </SectionCard>
              </div>
            )}

            {/* ── BUILD LOCALLY ── */}
            {activeSection === "build" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Build the Project Locally</h2>
                  <p className="text-gray-400">Compile ArbitrageX into production-ready files</p>
                </div>
                <Alert type="info">
                  The build output is a <strong>single self-contained <code>index.html</code></strong> file. You can open it directly in any browser or upload it to any web server.
                </Alert>
                <Step num={1} title="Clone or download the project">
                  <CodeBlock code={`git clone https://github.com/YOUR_USERNAME/arbitragex.git\ncd arbitragex`} />
                </Step>
                <Step num={2} title="Install dependencies">
                  <CodeBlock code={`npm install`} />
                </Step>
                <Step num={3} title="Build for production">
                  <CodeBlock code={`npm run build`} />
                  <p className="text-gray-400 mt-1">Creates a <code className="text-cyan-400 text-xs bg-gray-900/50 px-1.5 py-0.5 rounded">dist/</code> folder with your compiled app.</p>
                </Step>
                <Step num={4} title="Preview the production build">
                  <CodeBlock code={`npm run preview`} />
                  <p className="text-gray-400 mt-1">Opens a local server at <code className="text-cyan-400 text-xs bg-gray-900/50 px-1.5 py-0.5 rounded">http://localhost:4173</code></p>
                </Step>
                <Alert type="success">
                  <strong>The <code>dist/index.html</code> file is completely self-contained.</strong> Share it, host it anywhere — no server-side code required for the frontend.
                </Alert>
              </div>
            )}

            {/* ── VERCEL ── */}
            {activeSection === "vercel" && (
              <div>
                <div className="mb-6 flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-2xl font-bold text-black">▲</div>
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-white">Deploy to Vercel</h2>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      <Badge color="green">Recommended</Badge>
                      <Badge color="blue">Free Tier</Badge>
                      <Badge color="cyan">~3 min setup</Badge>
                    </div>
                  </div>
                </div>
                <Alert type="success">Vercel is the easiest option. Auto-deploys every time you push to GitHub. Free for personal projects.</Alert>
                <SectionCard title="Method 1 — Dashboard (No CLI)" icon="🖱️" accent="from-gray-700/20 to-gray-800/20">
                  <Step num={1} title="Push to GitHub">
                    <CodeBlock code={`git init\ngit add .\ngit commit -m "Initial commit"\ngit remote add origin https://github.com/YOUR_USERNAME/arbitragex.git\ngit push -u origin main`} />
                  </Step>
                  <Step num={2} title="Import on Vercel">
                    <p>Go to <span className="text-cyan-400 font-mono text-sm">https://vercel.com</span> → Sign in → <strong>Add New Project</strong> → Import your repo.</p>
                  </Step>
                  <Step num={3} title="Build settings">
                    <div className="bg-gray-900/60 rounded-xl p-4 space-y-2 text-sm">
                      {[["Framework", "Vite"], ["Build Command", "npm run build"], ["Output Dir", "dist"]].map(([k, v]) => (
                        <div key={k} className="flex gap-3"><span className="text-gray-400 w-32">{k}:</span><code className="text-cyan-400 bg-gray-800 px-2 py-0.5 rounded text-xs">{v}</code></div>
                      ))}
                    </div>
                  </Step>
                  <Step num={4} title="Click Deploy — done!">
                    <p className="text-gray-400">Your site goes live at <span className="text-cyan-400 font-mono">https://arbitragex.vercel.app</span></p>
                  </Step>
                </SectionCard>
                <SectionCard title="Method 2 — Vercel CLI" icon="💻" accent="from-gray-700/20 to-gray-800/20">
                  <CodeBlock code={`npm install -g vercel\nvercel\nvercel --prod`} />
                </SectionCard>
              </div>
            )}

            {/* ── NETLIFY ── */}
            {activeSection === "netlify" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Deploy to Netlify</h2>
                  <div className="flex flex-wrap gap-2 mt-1"><Badge color="green">Free Tier</Badge><Badge color="cyan">Drag & Drop Option</Badge></div>
                </div>
                <SectionCard title="Method 1 — Drag & Drop (Fastest)" icon="📂" accent="from-teal-500/10 to-green-500/10">
                  <Step num={1} title="Build locally"><CodeBlock code={`npm run build`} /></Step>
                  <Step num={2} title="Drag the dist/ folder"><p>Go to <span className="text-cyan-400 font-mono">https://app.netlify.com/drop</span> and drag your <code className="text-cyan-400 bg-gray-900/50 px-1.5 py-0.5 rounded text-xs">dist/</code> folder into the browser. Done!</p></Step>
                </SectionCard>
                <SectionCard title="Method 2 — Git Integration" icon="🔗" accent="from-gray-700/20 to-gray-800/20">
                  <Step num={1} title="Push to GitHub"><CodeBlock code={`git push origin main`} /></Step>
                  <Step num={2} title="Connect on Netlify"><p>Dashboard → <strong>New site from Git</strong> → Choose GitHub → Select repo → Build command: <code className="text-cyan-400 bg-gray-900/50 px-1.5 py-0.5 rounded text-xs">npm run build</code> → Publish dir: <code className="text-cyan-400 bg-gray-900/50 px-1.5 py-0.5 rounded text-xs">dist</code></p></Step>
                </SectionCard>
              </div>
            )}

            {/* ── GITHUB PAGES ── */}
            {activeSection === "github" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Deploy to GitHub Pages</h2>
                  <Badge color="purple">Free · Public repos</Badge>
                </div>
                <Alert type="warning">GitHub Pages requires setting a <code>base</code> path in vite.config.ts if your repo is not at the root domain.</Alert>
                <Step num={1} title="Update vite.config.ts">
                  <CodeBlock code={`// vite.config.ts\nexport default defineConfig({\n  plugins: [react()],\n  base: '/your-repo-name/',  // ← add this line\n})`} language="typescript" />
                </Step>
                <Step num={2} title="Install gh-pages"><CodeBlock code={`npm install -D gh-pages`} /></Step>
                <Step num={3} title="Add deploy script to package.json">
                  <CodeBlock code={`"scripts": {\n  "deploy": "npm run build && gh-pages -d dist"\n}`} language="json" />
                </Step>
                <Step num={4} title="Deploy"><CodeBlock code={`npm run deploy`} /></Step>
                <Step num={5} title="Enable GitHub Pages">
                  <p>Repository → Settings → Pages → Source: <code className="text-cyan-400 bg-gray-900/50 px-1.5 py-0.5 rounded text-xs">gh-pages branch</code></p>
                </Step>
              </div>
            )}

            {/* ── CLOUDFLARE ── */}
            {activeSection === "cloudflare" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Deploy to Cloudflare Pages</h2>
                  <div className="flex flex-wrap gap-2 mt-1"><Badge color="orange">Global CDN</Badge><Badge color="green">Free</Badge><Badge color="blue">Unlimited Bandwidth</Badge></div>
                </div>
                <Step num={1} title="Push to GitHub"><CodeBlock code={`git push origin main`} /></Step>
                <Step num={2} title="Create Cloudflare Pages project"><p>Go to <span className="text-cyan-400 font-mono">https://pages.cloudflare.com</span> → Connect to Git → Select repo.</p></Step>
                <Step num={3} title="Configure build">
                  <div className="bg-gray-900/60 rounded-xl p-4 space-y-2 text-sm">
                    {[["Framework preset", "Vite"], ["Build command", "npm run build"], ["Output directory", "dist"]].map(([k, v]) => (
                      <div key={k} className="flex gap-3"><span className="text-gray-400 w-36">{k}:</span><code className="text-cyan-400 bg-gray-800 px-2 py-0.5 rounded text-xs">{v}</code></div>
                    ))}
                  </div>
                </Step>
                <Step num={4} title="Deploy">
                  <p>Click <strong className="text-white">Save and Deploy</strong>. Live at <span className="text-cyan-400 font-mono">https://arbitragex.pages.dev</span></p>
                </Step>
              </div>
            )}

            {/* ── VPS ── */}
            {activeSection === "vps" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">VPS Server Deployment</h2>
                  <div className="flex flex-wrap gap-2 mt-1"><Badge color="blue">Advanced</Badge><Badge color="yellow">$5-10/mo</Badge><Badge color="red">Required for Real Backend</Badge></div>
                </div>
                <Alert type="info">A VPS is required if you want to run a real backend API proxy, cron jobs for scanning, or persistent bot execution.</Alert>
                <Step num={1} title="Connect to your VPS"><CodeBlock code={`ssh root@YOUR_SERVER_IP`} /></Step>
                <Step num={2} title="Install Node.js & Nginx"><CodeBlock code={`curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -\nsudo apt-get install -y nodejs nginx\nnode --version && npm --version`} /></Step>
                <Step num={3} title="Upload and build the project"><CodeBlock code={`# Clone from GitHub:\ngit clone https://github.com/YOUR_USERNAME/arbitragex.git\ncd arbitragex\nnpm install\nnpm run build`} /></Step>
                <Step num={4} title="Configure Nginx"><CodeBlock code={`sudo nano /etc/nginx/sites-available/arbitragex`} />
                  <CodeBlock code={`server {\n    listen 80;\n    server_name yourdomain.com www.yourdomain.com;\n    root /var/www/arbitragex/dist;\n    index index.html;\n    location / {\n        try_files $uri $uri/ /index.html;\n    }\n}`} language="nginx" /></Step>
                <Step num={5} title="Enable site & SSL"><CodeBlock code={`sudo ln -s /etc/nginx/sites-available/arbitragex /etc/nginx/sites-enabled/\nsudo nginx -t && sudo systemctl reload nginx\n# Free SSL with Certbot:\nsudo apt install certbot python3-certbot-nginx\nsudo certbot --nginx -d yourdomain.com`} /></Step>
              </div>
            )}

            {/* ── ENV VARS ── */}
            {activeSection === "envvars" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">API Keys & Environment Variables</h2>
                  <p className="text-gray-400">Securely configure exchange credentials</p>
                </div>
                <Alert type="danger">Never commit API keys to Git. Always use environment variables and add <code>.env</code> to <code>.gitignore</code>.</Alert>
                <SectionCard title=".env File Setup" icon="📄" accent="from-gray-700/20 to-gray-800/20">
                  <CodeBlock code={`# .env — NEVER commit this!\nVITE_BINANCE_API_KEY=your_binance_api_key\nVITE_BINANCE_SECRET=your_binance_secret\nVITE_BYBIT_API_KEY=your_bybit_api_key\nVITE_BYBIT_SECRET=your_bybit_secret\nVITE_MEXC_API_KEY=your_mexc_api_key\nVITE_MEXC_SECRET=your_mexc_secret\nVITE_HTX_API_KEY=your_htx_api_key\nVITE_HTX_SECRET=your_htx_secret\nVITE_KUCOIN_API_KEY=your_kucoin_api_key\nVITE_KUCOIN_SECRET=your_kucoin_secret\nVITE_KUCOIN_PASSPHRASE=your_kucoin_passphrase\nVITE_BITMART_API_KEY=your_bitmart_api_key\nVITE_BITMART_SECRET=your_bitmart_secret\nVITE_BITGET_API_KEY=your_bitget_api_key\nVITE_BITGET_SECRET=your_bitget_secret\nVITE_GATEIO_API_KEY=your_gateio_api_key\nVITE_GATEIO_SECRET=your_gateio_secret`} />
                  <CodeBlock code={`echo ".env" >> .gitignore`} />
                  <CodeBlock code={`// Access in code:\nconst apiKey = import.meta.env.VITE_BINANCE_API_KEY;`} language="typescript" />
                </SectionCard>
                <Alert type="warning">
                  <strong>CORS Note:</strong> Exchange APIs block direct browser requests. You need a backend proxy (Node.js on Vercel API routes or VPS) to forward requests with server-side API keys.
                </Alert>
              </div>
            )}

            {/* ── DOMAIN ── */}
            {activeSection === "domain" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Custom Domain Setup</h2>
                  <p className="text-gray-400">Point your domain to your deployed ArbitrageX</p>
                </div>
                <SectionCard title="Recommended Registrars" icon="🛒" accent="from-purple-500/10 to-pink-500/10">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { name: "Cloudflare Registrar", price: "~$10/yr", note: "At-cost, cheapest for .com",  url: "cloudflare.com/registrar" },
                      { name: "Namecheap",            price: "~$10/yr", note: "Free WHOIS privacy",          url: "namecheap.com" },
                      { name: "Porkbun",              price: "~$9/yr",  note: "Often has promos",            url: "porkbun.com" },
                      { name: "Squarespace DNS",      price: "~$12/yr", note: "Formerly Google Domains",     url: "domains.squarespace.com" },
                    ].map(r => (
                      <div key={r.name} className="bg-gray-900/50 rounded-xl p-3">
                        <div className="text-white font-semibold text-sm">{r.name}</div>
                        <div className="text-green-400 text-xs font-bold">{r.price}</div>
                        <div className="text-gray-500 text-xs mt-0.5">{r.note}</div>
                        <div className="text-cyan-500 text-xs font-mono mt-0.5">{r.url}</div>
                      </div>
                    ))}
                  </div>
                </SectionCard>
                <SectionCard title="DNS Records by Platform" icon="📡" accent="from-gray-700/20 to-gray-800/20">
                  {[
                    { platform: "Vercel",    icon: "▲",  records: [{ type: "A", name: "@", value: "76.76.21.21" }, { type: "CNAME", name: "www", value: "cname.vercel-dns.com" }] },
                    { platform: "Netlify",   icon: "🌐", records: [{ type: "A", name: "@", value: "75.2.60.5" },    { type: "CNAME", name: "www", value: "YOUR-SITE.netlify.app" }] },
                    { platform: "Cloudflare",icon: "☁️", records: [{ type: "CNAME", name: "@", value: "YOUR-SITE.pages.dev" }] },
                    { platform: "VPS",       icon: "🖥️", records: [{ type: "A", name: "@", value: "YOUR_SERVER_IP" }, { type: "A", name: "www", value: "YOUR_SERVER_IP" }] },
                  ].map(item => (
                    <div key={item.platform} className="mb-4">
                      <h4 className="text-white font-semibold text-sm mb-2">{item.icon} {item.platform}</h4>
                      <div className="bg-gray-900/60 rounded-xl overflow-hidden">
                        <table className="w-full text-xs">
                          <thead><tr className="border-b border-gray-700/50">{["Type","Name","Value"].map(h => <th key={h} className="text-left text-gray-500 py-2 px-4">{h}</th>)}</tr></thead>
                          <tbody>{item.records.map((r, i) => (
                            <tr key={i} className="border-b border-gray-800/50 last:border-0">
                              <td className="py-2 px-4"><Badge color="blue">{r.type}</Badge></td>
                              <td className="py-2 px-4 font-mono text-gray-300">{r.name}</td>
                              <td className="py-2 px-4 font-mono text-cyan-400">{r.value}</td>
                            </tr>
                          ))}</tbody>
                        </table>
                      </div>
                    </div>
                  ))}
                </SectionCard>
              </div>
            )}

            {/* ── SECURITY ── */}
            {activeSection === "security" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Security Checklist</h2>
                  <p className="text-gray-400">Essential practices before going live with real funds</p>
                </div>
                <Alert type="danger">This tool interacts with real exchange accounts and real funds. Follow all items below before connecting live API keys.</Alert>
                {[
                  { category: "API Key Security",  icon: "🔑", color: "red",    items: ["Never commit API keys to Git — use .env files","Enable IP whitelisting on ALL exchange API keys","Use separate keys: read-only for scanner, trade+withdraw for bot","Set withdrawal limits as a maximum safety cap","Rotate keys periodically and immediately if compromised"] },
                  { category: "Account Security",  icon: "🛡️", color: "orange", items: ["Enable 2FA on ALL exchange accounts","Enable 2FA on your hosting platform","Use strong unique passwords per exchange","Consider dedicated email for exchange accounts","Whitelist withdrawal addresses where possible"] },
                  { category: "Server Security",   icon: "🖥️", color: "blue",   items: ["Always use HTTPS — all platforms above provide free SSL","VPS: enable firewall (ufw allow 80,443 && ufw enable)","VPS: disable root SSH login, use SSH key auth","Keep dependencies updated regularly","Never expose secrets in browser-accessible code"] },
                  { category: "Trading Safety",    icon: "📊", color: "green",  items: ["Test with small amounts first — never start large","Start with scanner-only before enabling bot execution","Set conservative profit thresholds to avoid slippage","Monitor the bot actively — never leave fully unattended","Understand arbitrage opportunities can close faster than execution"] },
                ].map(section => (
                  <SectionCard key={section.category} title={section.category} icon={section.icon} accent={`from-${section.color}-500/10 to-${section.color}-600/5`}>
                    <div className="space-y-2">
                      {section.items.map((item, i) => (
                        <div key={i} className="flex items-start gap-3 bg-gray-900/30 rounded-lg p-3">
                          <span className="text-green-400 mt-0.5 flex-shrink-0">☐</span>
                          <span className="text-gray-300 text-sm">{item}</span>
                        </div>
                      ))}
                    </div>
                  </SectionCard>
                ))}
              </div>
            )}

            {/* ── TROUBLESHOOT ── */}
            {activeSection === "troubleshoot" && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">Troubleshooting</h2>
                  <p className="text-gray-400">Common issues and how to fix them</p>
                </div>
                {[
                  { problem: "Build fails with TypeScript errors", solution: "Check error in terminal. Fix type errors in the identified files.", code: `npm run build 2>&1 | head -80` },
                  { problem: "Blank white page after deployment", solution: "Open DevTools (F12) → Console. If on GitHub Pages with non-root path, set base in vite.config.ts.", code: `// vite.config.ts\nbase: '/your-repo-name/',`, language: "typescript" },
                  { problem: "CORS errors calling exchange APIs", solution: "Exchange APIs block direct browser requests. Create a backend proxy (Vercel API route / Express on VPS).", code: `// api/proxy.ts (Vercel)\nexport default async function handler(req, res) {\n  // proxy to exchange with server-side key\n}`, language: "typescript" },
                  { problem: "Site works locally but not in production", solution: "Missing env vars on hosting platform. Add all VITE_ variables in the dashboard and redeploy.", code: `vercel env ls` },
                  { problem: "npm install fails", solution: "Check Node.js version — requires v18+.", code: `node --version  # must be v18+\nnvm install 20 && nvm use 20` },
                  { problem: "Exchange API keys not working", solution: "Verify: correct permissions, IP whitelist includes server IP, key not expired, secret is correct.", code: `curl -H "X-MBX-APIKEY: YOUR_KEY" https://api.binance.com/api/v3/account` },
                ].map(item => (
                  <div key={item.problem} className="mb-5 bg-gray-800/40 border border-gray-700/50 rounded-2xl overflow-hidden">
                    <div className="flex items-start gap-3 p-4 border-b border-gray-700/30">
                      <span className="text-red-400 text-lg mt-0.5">⚠</span>
                      <div>
                        <h4 className="text-white font-semibold">{item.problem}</h4>
                        <p className="text-gray-400 text-sm mt-1">{item.solution}</p>
                      </div>
                    </div>
                    <div className="p-4 bg-gray-900/40">
                      <CodeBlock code={item.code} language={(item as { language?: string }).language || "bash"} />
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

export default DeploymentGuide;
